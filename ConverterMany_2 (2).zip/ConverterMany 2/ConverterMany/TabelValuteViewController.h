//
//  SecondViewController.h
//  ConverterMany
//
//  Created by Student on 05.11.16.
//  Copyright © 2016 CFT:FocusStart. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecondViewController : UIViewController

@end
