//
//  TableValueWantedClose.h
//  ConverterMany
//
//  Created by Student on 05.11.16.
//  Copyright © 2016 CFT:FocusStart. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol TableValueWantedClose <NSObject>

@end
